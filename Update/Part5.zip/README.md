# Part5-Coding Exercises

海明皓 17343037

## 1

### 设计思路

​	本题是利用链表代替数组重写BoundedGrid类，加快代码的效率。首先，我们需要对链表中的元素结构作定义，为此我们创建了一个节点类SparseGridNode。其三个基本的私有变量如下所示：

```java
private Object occupant;
private int col;
private SparseGridNode next;
```

​	这三个变量分别表示当前节点在图中对应的物体、列号、在当前列中的下一个节点。我们只对该位置有元素的格子进行存储，这样在面积大的稀疏图中会节省相当大的存储空间。如果next为空，则说明该节点是当前列中最后一个节点了。

​	然后，为了方便我们的函数获取和修改这三个变量，我们对这三个变量分别定义了getter和setter方法，比如occupant变量的实现如下：

```java
// getter
public Object getOccupant()
{
    return occupant;
}

// setter
public void setOccupant(Object object)
{
    occupant = object;
}
```

​	然后，我们就需要重写BoundedGrid类，我们命令为SparseBoundedGrid，我们将原来的二维数组改成存储节点的一维数组：

```java
private SparseGridNode[] store;
```

​	在构造函数中，我们定义其大小等于行数，这样就可以根据行号来找到对应的列链表了：

```java
store = new SparseGridNode[rowNum];
```

​	这样，我们再根据这个结构对应修改其他方法实现中查找元素的部分。比如说，`getOccupiedLocations`函数我们就不再进行嵌套循环的遍历了，而是首先在外层遍历store：

```java
for (int i = 0; i < getNumRows(); ++ i)
{
	// ...
}
```

​	在内层，我们只需从链表头一直找到链表尾即可，当发现了非空的节点时，就将这个节点对应的位置使用Location存储，并加入到temp中，最后返回temp即可：

```java
SparseGridNode node = store[i];
while (node != null)
{
    Location loc = new Location(i, node.getCol());
    temp.add(loc);
    node = node.getNext();
}
```

​	其他方法的实现类似。

### 问题回答

1. Why is this a more time-efficient implementation than BoundedGrid?

   ​	在原本的BoundedGrid类中，使用数组进行存储，各个方法`getOccupiedLocatons`，`get`, `put`,`remove`等，需要利用两个嵌套的循环来遍历所有的元素，如下所示：

   ```java
   // Look at all grid locations.
   for (int r = 0; r < getNumRows(); r++)
   {
       for (int c = 0; c < getNumCols(); c++)
       {
           // If there's an object at this location, put it in the array.
           Location loc = new Location(r, c);
           if (get(loc) != null)
               theLocations.add(loc);
       }
   }
   ```

   ​	其时间复杂度为O(col * row)。而根据链表的实现，并不需要搜索全部位置，只需利用链表头来找到相对应的元素：

   ```java
   for (int i = 0; i < getNumRows(); ++ i)
   {
       SparseGridNode node = store[i];
       while (node != null)
       {
           Location loc = new Location(i, node.getCol());
           temp.add(loc);
           node = node.getNext();
       }
   }
   ```

   ​	其时间复杂度为O(col * n)，n表示稀疏图的被占据的位置个数。

## 2

### 设计思路

​	本题是利用了map来建立表格，相比于链表，其实现会稍微简单一些。map结构将每个位置和对应的物体对应起来，其数据结构定义如下所示：

```java
private Map<Location, E> store;
```

​	此处我们可以借鉴UnboundedGrid类中的实现，因为其也是通过map结构来存储位置和对象的映射关系。`getOccupiedLocation` , `get` , `put` , `remove`这几个函数的实现完全一样，可以直接拿过来用，比如get函数：

```java
public E get(Location loc)
{
    if (!isValid(loc)) {
        throw new IllegalArgumentException("Location " + loc + " is not valid");
    }
    return store.get(loc);
}
```

​	其实只需要从map中找出和loc对应的物体即可，而剩下的函数都不难，稍微加以改动即可实现本类。

### 问题回答

1. Which methods of UnboundedGrid could be used without change?

   `getOccupiedLocation` , `get` , `put` , `remove`这四个函数不需要改变就可以直接使用

2. Fill in the following chart to compare the expected Big-Oh efficiencies for each implementation of the `SparseBoundedGrid`，Let r = number of rows, c = number of columns, and n = number of occupied locations

   ​	要完成本表，主要是看每个函数对应的方法在哪里和以上三个参数产生联系，比如`getNeighbors`方法就会调用`get`函数，通过loc找到对应的对象，根据不同的数据结构，其查询的时间复杂度也不一样，链表和c成正比、哈希查询是O(1)的复杂度、而TreeMap查询是O(log n)的复杂度。

   ​	另外的方法也是类似的，基本上最花费时间的地方都是从某个loc查找对应的物体，也就是查询步骤，这就直接涉及到对应数据结构的查询时间复杂度了。

   |           Methods            | SparseGridNode version | LinkedList<OccupantInCol> version | HashMap version | TreeMap version |
   | :--------------------------: | :--------------------: | :-------------------------------: | :-------------: | :-------------: |
   |         getNeighbors         |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |
   |  getEmptyAdjacentLocations   |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |
   | getOccupiedAdjacentLocations |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |
   |     getOccupiedLocations     |         O(r+n)         |              O(r+n)               |      O(n)       |      O(n)       |
   |             get              |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |
   |             put              |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |
   |            remove            |          O(c)          |               O(c)                |      O(1)       |    O(log n)     |

## 3

### 设计思路

​	本题主要是利用数组实现无边界的网格，规定当行列数不够时，我们直接将原来的网格扩大两倍。我们还是首先定义好数据结构：

```java
private Object[][] store;
```

​	在需要进行扩展的时候，我们直接创建一个新的二维数组，扩大空间，然后将原来所有的元素进行存放。

```java
if (loc.getRow() >= row || loc.getCol() >= row)
{
    int newRow = row;
    // extend the array
    while (loc.getRow() >= newRow || loc.getCol() >= newRow) 
    {
        newRow *= 2;
    }
    Object [][] newStore = new Object[newRow][newRow];
    // copy
    for (int i = 0; i < row; ++ i)
    {
        for (int j = 0; j < row; ++ j)
        {
            newStore[i][j] = store[i][j];
        }
    }
    // set
    row = newRow;
    store = newStore;
}
```

​	 其他函数的实现直接利用二维数组的特性获取相对应的元素即可，不过这样的设计会比较耗费空间。

### 问题回答

1. What is the Big-Oh efficiency of the get method? What is the efficiency of the put method when the row and column index values are within the current array bounds? What is the efficiency when the array needs to be resized?

   ​	`get`的复杂度是O(1)；当不需要扩增时，`put`的复杂度也是O(1)；当需要扩增时，由于复制的开销，需要将所有的元素都复制一遍：

   ```java
   // copy
   for (int i = 0; i < row; ++ i)
   {
       for (int j = 0; j < row; ++ j)
       {
           newStore[i][j] = store[i][j];
       }
   }
   ```

    	所以复杂度变为O(row * col)。